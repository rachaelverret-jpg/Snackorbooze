function unroll(squareArray) {

}

module.exports = unroll;
